const jwt = require('jsonwebtoken');
const UserModel = require('../models/user.model');
const IpWhitelistModel = require('../models/ipWhitelist.model');
const net = require('net');
const AppError = require('../utils/AppError');

const JWT_SECRET = process.env.JWT_SECRET || 'hepco_secret_key_123';

exports.login = async (req, res, next) => {
  const { username, password } = req.body;
  let clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  
  if (clientIp) {
    if (clientIp.includes(',')) {
      clientIp = clientIp.split(',')[0].trim();
    }
    if (clientIp.includes('::ffff:')) {
      clientIp = clientIp.split('::ffff:')[1];
    }
    if (clientIp === '::1') {
      clientIp = '127.0.0.1';
    }
  }

  if (!username || !password) {
    return next(new AppError('MISSING_CREDENTIALS', 400, 'Thiếu thông tin đăng nhập'));
  }
  
  if (!net.isIPv4(clientIp)) {
    return next(new AppError('ONLY_IPV4_ALLOWED', 403, 'Chỉ hỗ trợ IPv4'));
  }
  
  try {
    // 2. Authenticate account
    const users = await UserModel.findByUsernameAndPassword(username, password);

    if (users.length > 0) {
      const user = users[0];
      
      // 3. Create Bearer Token
      const token = jwt.sign(
        { id: user.id, username: user.username },
        JWT_SECRET,
        { expiresIn: '1d' } // Token expires in 1 day
      );

      res.json({ 
        success: true, 
        user: user,
        token: token // Return token
      });
    } else {
      next(new AppError('INVALID_CREDENTIALS', 401, 'Tài khoản hoặc mật khẩu không chính xác'));
    }
  } catch (err) {
    next(new AppError('INTERNAL_ERROR', 500, err.message));
  }
};
