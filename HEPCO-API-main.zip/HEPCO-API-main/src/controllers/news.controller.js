const NewsModel = require('../models/news.model');
const AppError = require('../utils/AppError');

exports.getAllNews = async (req, res, next) => {
  try {
    const { type, page = 1, limit = 20, search = '' } = req.query;
    const news = await NewsModel.getAll(type, page, limit, search);
    res.json(news);
  } catch (err) {
    next(new AppError('FETCH_FAILED', 500, err.message));
  }
};

exports.getNewsById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const article = await NewsModel.getById(id);
    if (!article) {
      return next(new AppError('ARTICLE_NOT_FOUND', 404, 'Không tìm thấy bài viết'));
    }
    res.json(article);
  } catch (err) {
    next(new AppError('FETCH_FAILED', 500, err.message));
  }
};

exports.createNews = async (req, res, next) => {
  const { title, content, thumbnail, type, date } = req.body;
  if (!title || !content) {
    return next(new AppError('MISSING_REQUIRED_FIELDS', 400, 'Thiếu thông tin bắt buộc'));
  }

  let formattedDate = date;
  if (!formattedDate) {
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    const hours = String(today.getHours()).padStart(2, '0');
    const minutes = String(today.getMinutes()).padStart(2, '0');
    formattedDate = `${day}-${month}-${year} ${hours}:${minutes}`;
  }

  const author_id = req.user?.id || 1;
  const articleType = type || 'news';
  const articleThumbnail = thumbnail || '';

  try {
    await NewsModel.create({
      title,
      date: formattedDate,
      author_id,
      content,
      thumbnail: articleThumbnail,
      type: articleType
    });

    res.status(201).json({ success: true });
  } catch (err) {
    next(new AppError('CREATE_FAILED', 500, err.message));
  }
};

exports.updateNews = async (req, res, next) => {
  const { id } = req.params;
  const { title, content, thumbnail, type, date } = req.body;
  if (!title || !content) {
    return next(new AppError('MISSING_REQUIRED_FIELDS', 400, 'Thiếu thông tin bắt buộc'));
  }

  try {
    await NewsModel.update(id, {
      title,
      content,
      thumbnail: thumbnail || '',
      type: type || 'news',
      date
    });
    res.json({ success: true });
  } catch (err) {
    next(new AppError('UPDATE_FAILED', 500, err.message));
  }
};

exports.deleteNews = async (req, res, next) => {
  const { id } = req.params;
  try {
    await NewsModel.delete(id);
    res.json({ success: true });
  } catch (err) {
    next(new AppError('DELETE_FAILED', 500, err.message));
  }
};
