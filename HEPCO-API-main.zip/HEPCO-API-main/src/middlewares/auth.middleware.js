const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'hepco_secret_key_123';

exports.verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(403).json({ errorCode: 'TOKEN_MISSING' });
  }

  const token = authHeader.split(' ')[1];

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ errorCode: 'TOKEN_INVALID_OR_EXPIRED' });
    }
    
    // Save user info in request for use in controllers
    req.user = decoded;
    next();
  });
};
