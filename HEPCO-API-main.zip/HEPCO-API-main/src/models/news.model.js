const { prisma } = require('../db');

class NewsModel {
  static async getAll(typeOrParams, pageArg = 1, limitArg = 20, searchArg = '') {
    let type, page, limit, search, sort;
    if (typeOrParams && typeof typeOrParams === 'object') {
      ({ type, page = 1, limit = 20, search = '', sort } = typeOrParams);
    } else {
      type = typeOrParams;
      page = pageArg;
      limit = limitArg;
      search = searchArg;
    }

    const offset = (Number(page) - 1) * Number(limit);

    const where = {};
    if (type) {
      if (Array.isArray(type)) {
        where.type = { in: type };
      } else if (typeof type === 'string' && type.includes(',')) {
        where.type = { in: type.split(',').map((t) => t.trim()) };
      } else {
        where.type = type;
      }
    }
    if (search) {
      where.title = {
        contains: search
      };
    }

    let orderBy = { created_at: 'desc' };
    if (sort === 'title_asc') orderBy = { title: 'asc' };
    else if (sort === 'title_desc') orderBy = { title: 'desc' };
    else if (sort === 'created_at_asc') orderBy = { created_at: 'asc' };
    else if (sort === 'created_at_desc') orderBy = { created_at: 'desc' };
    else orderBy = { id: 'desc' };

    const [total, data] = await Promise.all([
      prisma.news.count({ where }),
      prisma.news.findMany({
        where,
        skip: offset,
        take: parseInt(limit),
        orderBy
      })
    ]);

    return {
      data,
      meta: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / limit)
      }
    };
  }

  static async getById(id) {
    return await prisma.news.findUnique({
      where: { id: parseInt(id) }
    });
  }

  static async create(newsData) {
    const { title, date, author_id, content, thumbnail, type } = newsData;
    await prisma.news.create({
      data: {
        title,
        date,
        author_id,
        content,
        thumbnail,
        type
      }
    });
  }

  static async update(id, newsData) {
    const { title, content, thumbnail, type, date } = newsData;
    const updateData = {
      title,
      content,
      thumbnail,
      type
    };
    if (date) {
      updateData.date = date;
    }
    await prisma.news.update({
      where: { id: parseInt(id) },
      data: updateData
    });
  }

  static async delete(id) {
    await prisma.news.delete({
      where: { id: parseInt(id) }
    });
  }
}

module.exports = NewsModel;
