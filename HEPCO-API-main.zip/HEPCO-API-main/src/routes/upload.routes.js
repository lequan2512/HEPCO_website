const express = require('express');
const router = express.Router();
const multer = require('multer');
const { CloudinaryStorage } = require('multer-storage-cloudinary');
const cloudinary = require('cloudinary').v2;
const authMiddleware = require('../middlewares/auth.middleware');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'hepco_news',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp', 'gif'],
  },
});

const upload = multer({ storage: storage });

router.post('/', authMiddleware.verifyToken, upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ errorCode: 'NO_FILE_UPLOADED' });
  }
  res.json({ success: true, url: req.file.path });
});

router.delete('/', authMiddleware.verifyToken, async (req, res) => {
  const { url } = req.body;
  if (!url) {
    return res.status(400).json({ errorCode: 'MISSING_URL' });
  }

  try {
    const splitUrl = url.split('/');
    const filenameWithExt = splitUrl[splitUrl.length - 1];
    const filename = filenameWithExt.split('.')[0];
    const publicId = `hepco_news/${filename}`;

    await cloudinary.uploader.destroy(publicId);
    return res.json({ success: true, message: 'File deleted' });
  } catch (err) {
    console.error('Lỗi khi xóa file:', err);
    return res.status(500).json({ errorCode: 'DELETE_FAILED' });
  }
});

module.exports = router;
